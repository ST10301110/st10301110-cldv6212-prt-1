﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Files.Shares;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace ABC_Retail.Functions
{
    public class FileStorageFunction
    {
        private readonly ILogger<FileStorageFunction> _logger;

        public FileStorageFunction(ILogger<FileStorageFunction> logger)
        {
            _logger = logger;
        }

        [Function("UploadToFileShare")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            _logger.LogInformation("Processing file share upload request.");

            try
            {
                // Check if we have content
                if (req.Body == null || req.Body.Length == 0)
                {
                    var errorResponse = req.CreateResponse(HttpStatusCode.BadRequest);
                    await errorResponse.WriteStringAsync("No file data provided.");
                    return errorResponse;
                }

                // Get connection string from environment
                var connectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
                var shareClient = new ShareClient(connectionString, "documents");
                await shareClient.CreateIfNotExistsAsync();

                var directoryClient = shareClient.GetDirectoryClient("orders");
                await directoryClient.CreateIfNotExistsAsync();

                var fileName = $"file_{Guid.NewGuid()}.dat";
                var fileClient = directoryClient.GetFileClient(fileName);

                await fileClient.CreateAsync(req.Body.Length);
                await fileClient.UploadRangeAsync(new Azure.HttpRange(0, req.Body.Length), req.Body);

                _logger.LogInformation($"File uploaded to file share successfully: {fileName}");

                var response = req.CreateResponse(HttpStatusCode.OK);
                await response.WriteAsJsonAsync(new
                {
                    success = true,
                    fileName = fileName,
                    message = "File uploaded to file share successfully"
                });

                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error uploading to file share: {ex.Message}");

                var errorResponse = req.CreateResponse(HttpStatusCode.InternalServerError);
                await errorResponse.WriteStringAsync($"Error uploading file: {ex.Message}");
                return errorResponse;
            }
        }
    }
}
