﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Azure.Storage.Queues;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace ABC_Retail.Functions
{
    public class QueueOperationsFunction
    {
        private readonly ILogger<QueueOperationsFunction> _logger;

        public QueueOperationsFunction(ILogger<QueueOperationsFunction> logger)
        {
            _logger = logger;
        }

        [Function("SendQueueMessage")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            _logger.LogInformation("Processing queue message request.");

            try
            {
                var requestBody = await req.ReadAsStringAsync();
                var queueData = JsonSerializer.Deserialize<QueueMessageRequest>(requestBody);

                if (queueData == null || string.IsNullOrEmpty(queueData.QueueName) || string.IsNullOrEmpty(queueData.Message))
                {
                    var errorResponse = req.CreateResponse(HttpStatusCode.BadRequest);
                    await errorResponse.WriteStringAsync("Queue name and message are required.");
                    return errorResponse;
                }

                var connectionString = Environment.GetEnvironmentVariable("AzureWebJobsStorage");
                var queueClient = new QueueClient(connectionString, queueData.QueueName.ToLower());
                await queueClient.CreateIfNotExistsAsync();

                var messageJson = JsonSerializer.Serialize(new
                {
                    Message = queueData.Message,
                    Timestamp = DateTime.UtcNow,
                    Source = "ABC_Retail_App"
                });

                await queueClient.SendMessageAsync(messageJson);

                _logger.LogInformation($"Message sent to queue {queueData.QueueName} successfully.");

                var response = req.CreateResponse(HttpStatusCode.OK);
                await response.WriteAsJsonAsync(new
                {
                    success = true,
                    queueName = queueData.QueueName,
                    message = "Message sent to queue successfully"
                });

                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error sending queue message: {ex.Message}");

                var errorResponse = req.CreateResponse(HttpStatusCode.InternalServerError);
                await errorResponse.WriteStringAsync($"Error sending message: {ex.Message}");
                return errorResponse;
            }
        }
    }

    public class QueueMessageRequest
    {
        public string QueueName { get; set; }
        public string Message { get; set; }
    }
}
