﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Azure.Data.Tables;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using ABC_Retail_Project.Models;

namespace ABC_Retail.Functions
{
    public class OrderProcessorFunction
    {
        private readonly TableServiceClient _tableServiceClient;
        private readonly ILogger<OrderProcessorFunction> _logger;

        public OrderProcessorFunction(TableServiceClient tableServiceClient, ILogger<OrderProcessorFunction> logger)
        {
            _tableServiceClient = tableServiceClient;
            _logger = logger;
        }

        [Function("OrderProcessor")]
        public async Task Run([QueueTrigger("orders-queue")] string queueItem)
        {
            _logger.LogInformation($"Processing order from queue: {queueItem}");

            try
            {
                var options = new JsonSerializerOptions
                {
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                    PropertyNameCaseInsensitive = true, // Added for flexibility
                    Converters = { new DateTimeConverterUsingDateTimeParse() }
                };

                var orderData = JsonSerializer.Deserialize<OrderQueueMessage>(queueItem, options);

                if (orderData == null)
                {
                    _logger.LogError("Failed to deserialize queue message");
                    return;
                }

                var tableClient = _tableServiceClient.GetTableClient("Orders");
                await tableClient.CreateIfNotExistsAsync();

                // Ensure DateTime is UTC for Azure Table Storage
                var orderDateUtc = orderData.OrderDate.Kind == DateTimeKind.Unspecified
                    ? DateTime.SpecifyKind(orderData.OrderDate, DateTimeKind.Utc)
                    : orderData.OrderDate.ToUniversalTime();

                var entity = new TableEntity(orderData.PartitionKey, orderData.RowKey)
                {
                    ["CustomerId"] = orderData.CustomerId,
                    ["ProductId"] = orderData.ProductId,
                    ["Quantity"] = orderData.Quantity,
                    ["TotalAmount"] = orderData.TotalAmount,
                    ["OrderDate"] = orderDateUtc,
                    ["Status"] = orderData.Status
                };

                await tableClient.AddEntityAsync(entity);
                _logger.LogInformation($"Order {orderData.RowKey} successfully processed and saved to table.");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error processing order from queue: {ex.Message}");
                _logger.LogError($"Stack trace: {ex.StackTrace}");
                throw;
            }
        }
    }

    public class OrderQueueMessage
    {
        public string PartitionKey { get; set; } = string.Empty;
        public string RowKey { get; set; } = string.Empty;
        public string CustomerId { get; set; } = string.Empty;
        public string ProductId { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime OrderDate { get; set; }
        public string Status { get; set; } = "Pending";
    }

    public class DateTimeConverterUsingDateTimeParse : JsonConverter<DateTime>
    {
        public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            return DateTime.Parse(reader.GetString() ?? string.Empty);
        }

        public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
        }
    }
}