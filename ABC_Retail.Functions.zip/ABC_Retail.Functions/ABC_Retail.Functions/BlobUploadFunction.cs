﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace ABC_Retail.Functions
{
    public class BlobUploadFunction
    {
        private readonly BlobServiceClient _blobServiceClient;
        private readonly ILogger<BlobUploadFunction> _logger;

        public BlobUploadFunction(BlobServiceClient blobServiceClient, ILogger<BlobUploadFunction> logger)
        {
            _blobServiceClient = blobServiceClient;
            _logger = logger;
        }

        [Function("UploadBlob")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequestData req)
        {
            _logger.LogInformation("Processing blob upload request.");

            try
            {
                // For .NET 8 Isolated, we need to handle file uploads differently
                // This is a simplified version - in production, you'd use proper file handling
                var response = req.CreateResponse(HttpStatusCode.OK);

                // Check if we have content (simplified approach)
                if (req.Body == null || req.Body.Length == 0)
                {
                    var errorResponse = req.CreateResponse(HttpStatusCode.BadRequest);
                    await errorResponse.WriteStringAsync("No file data provided.");
                    return errorResponse;
                }

                var containerClient = _blobServiceClient.GetBlobContainerClient("uploads");
                await containerClient.CreateIfNotExistsAsync();

                var fileName = $"upload_{Guid.NewGuid()}.dat";
                var blobClient = containerClient.GetBlobClient(fileName);

                await blobClient.UploadAsync(req.Body, overwrite: true);

                _logger.LogInformation($"File uploaded successfully: {fileName}");

                await response.WriteAsJsonAsync(new
                {
                    success = true,
                    blobUrl = blobClient.Uri.ToString(),
                    fileName = fileName,
                    message = "File uploaded successfully"
                });

                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error uploading blob: {ex.Message}");

                var errorResponse = req.CreateResponse(HttpStatusCode.InternalServerError);
                await errorResponse.WriteStringAsync($"Error uploading file: {ex.Message}");
                return errorResponse;
            }
        }
    }
}
